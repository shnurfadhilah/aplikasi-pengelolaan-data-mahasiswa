package com.nurfadhilah.NurfadhilahSeptiandi_14519006;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class APPAbout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appabout);
        getSupportActionBar().setTitle("Tentang Aplikasi");
    }

    public void webviewblog(View view) {
        Intent intent = new Intent(APPAbout.this, WebViewBlog.class);
        startActivity(intent);
    }
}