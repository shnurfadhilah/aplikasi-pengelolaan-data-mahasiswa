package com.nurfadhilah.NurfadhilahSeptiandi_14519006;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ListView extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item);
    }
}