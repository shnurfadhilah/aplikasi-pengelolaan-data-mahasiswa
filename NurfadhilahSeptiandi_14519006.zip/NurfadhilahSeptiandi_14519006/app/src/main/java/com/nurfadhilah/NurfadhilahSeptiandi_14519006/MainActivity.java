package com.nurfadhilah.NurfadhilahSeptiandi_14519006;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.HashMap;


public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        String str="Haloo !! Selamat Datang !!";
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_LONG).show();
    }

    public void appabout(View view) {
        Intent intent = new Intent(MainActivity.this, APPAbout.class);
        startActivity(intent);
    }


    public void masuk(View view) {
        Intent intent = new Intent(MainActivity.this, TampilSemuaMhs.class);
        startActivity(intent);
    }

    public void tambah(View view) {
        Intent intent = new Intent(MainActivity.this, TambahMhs.class);
        startActivity(intent);
    }

    public void edit(View view) {
        Intent intent = new Intent(MainActivity.this, TampilSemuaEdit.class);
        startActivity(intent);
    }

    public void delete(View view) {
        Intent intent = new Intent(MainActivity.this, TampilSemuaDelt.class);
        startActivity(intent);
    }

}