package com.nurfadhilah.NurfadhilahSeptiandi_14519006;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class TampilMhs extends AppCompatActivity{
    private EditText editTextId;
    private EditText editTextName;
    private EditText editTextNRP;
    private EditText editTextKelas;
    private EditText editTextBlog;
    private String id;

    WebView webView;
    ProgressBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_mhs);
        getSupportActionBar().setTitle("Info Detail Mahasiswa");

        Intent intent = getIntent();
        id = intent.getStringExtra(konfigurasi.MHS_ID);
        editTextId = (EditText) findViewById(R.id.editTextId);
        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextNRP = (EditText) findViewById(R.id.editTextNRP);
        editTextKelas = (EditText) findViewById(R.id.editTextKelas);
        editTextBlog = (EditText) findViewById(R.id.editTextBlog);
        editTextId.setText(id);
        getMhs();
    }
    private void getMhs(){
        class GetMhs extends AsyncTask<Void,Void,String>{ ProgressDialog loading;
            @Override
            protected void onPreExecute() { super.onPreExecute();
                loading = ProgressDialog.show(TampilMhs.this,"Fetching...","Wait...",false,false);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                showMhs(s);
            }
            @Override
            protected String doInBackground(Void... params) { RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_GET_EMP,id);
                return s;
            }
        }
        GetMhs ge = new GetMhs();
        ge.execute();
    }
    private void showMhs(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(konfigurasi.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String name = c.getString(konfigurasi.TAG_NAMA);
            String nrp = c.getString(konfigurasi.TAG_NRP);
            String kelas = c.getString(konfigurasi.TAG_KELAS);
            String blog = c.getString(konfigurasi.TAG_BLOG);
            editTextName.setText(name);
            editTextNRP.setText(nrp);
            editTextKelas.setText(kelas);
            editTextBlog.setText(blog);
        }
        catch (JSONException e) { e.printStackTrace();
        }
    }
}
