package com.nurfadhilah.NurfadhilahSeptiandi_14519006;

public class konfigurasi {
    public static final String URL_ADD="http://shnurfadhilah.000webhostapp.com/mahasiswa/tambahMhs.php";
    public static final String URL_GET_ALL = "http://shnurfadhilah.000webhostapp.com/mahasiswa/tampilSemuaMhs.php";
    public static final String URL_GET_EMP ="http://shnurfadhilah.000webhostapp.com/mahasiswa/tampilMhs.php?id=";
    public static final String URL_UPDATE_EMP = "http://shnurfadhilah.000webhostapp.com/mahasiswa/updateMhs.php";
    public static final String URL_DELETE_EMP = "http://shnurfadhilah.000webhostapp.com/mahasiswa/hapusMhs.php?id=";

    public static final String KEY_MHS_ID = "id";
    public static final String KEY_MHS_NAMA = "name";
    public static final String KEY_MHS_NRP = "nrp";
    public static final String KEY_MHS_KELAS = "kelas";
    public static final String KEY_MHS_BLOG = "blog";

    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "name";
    public static final String TAG_NRP = "nrp";
    public static final String TAG_KELAS = "kelas";
    public static final String TAG_BLOG = "blog";

    public static final String MHS_ID = "mhs_id";
}