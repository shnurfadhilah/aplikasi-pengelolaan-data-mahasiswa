package com.nurfadhilah.NurfadhilahSeptiandi_14519006;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class spinner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.spinner_item);
    }
}